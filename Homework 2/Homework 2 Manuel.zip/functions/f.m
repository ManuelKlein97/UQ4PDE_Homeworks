function y = f(x)
    y = 4*pi^2*cos(2*pi*x);
end